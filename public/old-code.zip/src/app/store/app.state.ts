export interface AppState {
  headerText: string;
}

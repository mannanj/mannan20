import { TestBed } from '@angular/core/testing';
import { DataService } from './data.service';

describe('DataService', () => {
  let service: DataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return resume data observable', (done) => {
    service.getResumeData().subscribe(data => {
      expect(data).toBeTruthy();
      expect(data.experiences).toBeDefined();
      expect(data.education).toBeDefined();
      expect(data.skills).toBeDefined();
      done();
    });
  });
});

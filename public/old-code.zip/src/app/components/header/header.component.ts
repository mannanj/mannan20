import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationService } from '../../services/navigation.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="flex justify-between items-center fixed top-0 w-screen bg-[#0b0b0b] border-b border-white h-[66px] z-[99]">
      <div class="flex items-center relative z-[-99] hover:cursor-pointer">
        <img src="mannan.jpg" width="48" height="48" class="rounded-full">
      </div>
      <div class="flex pr-[50px] pl-[15px]" *ngIf="navService.selectedLink$ | async as link">
        <a id="home-link"
           [class.selected]="link === 'home'"
           class="text-white cursor-pointer relative pl-[15px] after:content-[''] after:absolute after:w-0 after:h-[2px] after:bottom-[-25px] after:left-0 after:bg-[#4fc3f7] after:transition-[width] after:duration-300 after:ease-in-out hover:after:w-full [&.selected]:after:w-full [&.selected]:after:bg-[#039be5]"
           (click)="navService.goTo(navService.Links.home)">Home</a>
        <a id="about-link"
           [class.selected]="link === 'about'"
           class="text-white cursor-pointer relative pl-[15px] after:content-[''] after:absolute after:w-0 after:h-[2px] after:bottom-[-25px] after:left-0 after:bg-[#4fc3f7] after:transition-[width] after:duration-300 after:ease-in-out hover:after:w-full [&.selected]:after:w-full [&.selected]:after:bg-[#039be5]"
           (click)="navService.goTo(navService.Links.about)">About</a>
        <a id="resume-link"
           [class.selected]="link === 'resume'"
           class="text-white cursor-pointer relative pl-[15px] after:content-[''] after:absolute after:w-0 after:h-[2px] after:bottom-[-25px] after:left-0 after:bg-[#4fc3f7] after:transition-[width] after:duration-300 after:ease-in-out hover:after:w-full [&.selected]:after:w-full [&.selected]:after:bg-[#039be5]"
           (click)="navService.goTo(navService.Links.resume)">Resume</a>
        <a id="contact-link"
           [class.selected]="link === 'contact'"
           class="text-white cursor-pointer relative pl-[15px] after:content-[''] after:absolute after:w-0 after:h-[2px] after:bottom-[-25px] after:left-0 after:bg-[#4fc3f7] after:transition-[width] after:duration-300 after:ease-in-out hover:after:w-full [&.selected]:after:w-full [&.selected]:after:bg-[#039be5]"
           (click)="navService.goTo(navService.Links.contact)">Contact</a>
      </div>
    </div>
  `,
  styles: [],
})
export class HeaderComponent {
  constructor(public navService: NavigationService) {}
}

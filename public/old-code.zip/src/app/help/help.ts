import * as vew from 'src/app/help/view';

export const help = {vew};
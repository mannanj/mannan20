import * as vew from 'src/app/forms/view';

export const forms = {vew};

// This way didn't work.
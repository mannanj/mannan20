export enum Links {
    home = 'home',
    about = 'about',
    resume = 'resume',
    contact = 'contact'
}
